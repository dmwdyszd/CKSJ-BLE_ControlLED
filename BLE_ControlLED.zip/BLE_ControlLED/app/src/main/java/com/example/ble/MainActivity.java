package com.example.ble;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    // 蓝牙相关
    private BluetoothManager bluetoothManager;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothGatt bluetoothGatt;
    private BluetoothGattCharacteristic writeCharacteristic;

    // UI组件
    private Button btnScan;
    private ListView lvDevices;
    private Button btnRed;
    private Button btnBlue;
    private Button btnClose;
    private TextView tvStatus;

    // 扫描相关
    private Set<BluetoothDevice> scannedDevices = new HashSet<>();
    private ArrayAdapter<String> deviceAdapter;
    private Handler scanHandler = new Handler(Looper.getMainLooper());
    private static final long SCAN_PERIOD = 10000; // 扫描时长10秒
    private boolean isScanning = false;

    // BLE扫描回调
    private BluetoothAdapter.LeScanCallback leScanCallback = new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
            if (!scannedDevices.contains(device)) {
                scannedDevices.add(device);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String deviceName = device.getName() == null ? "未知设备" : device.getName();
                        deviceAdapter.add(deviceName + "(" + device.getAddress() + ")");
                    }
                });
            }
        }
    };

    // BLE GATT回调
    private BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        tvStatus.setText("通信状态：已连接，正在发现服务...");
                        // 发现服务
                        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT)
                                != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                        gatt.discoverServices();
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        tvStatus.setText("通信状态：已断开连接");
                        writeCharacteristic = null;
                        if (bluetoothGatt != null) {
                            bluetoothGatt.close();
                            bluetoothGatt = null;
                        }
                    }
                }
            });
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (status == BluetoothGatt.GATT_SUCCESS) {
                        // 查找可写特征
                        findWritableCharacteristic(gatt);
                        tvStatus.setText("通信状态：已连接，可发送数据");
                    } else {
                        tvStatus.setText("通信状态：已连接，但服务发现失败");
                    }
                }
            });
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (status == BluetoothGatt.GATT_SUCCESS) {
                        String data = new String(characteristic.getValue(), StandardCharsets.UTF_8);
                        tvStatus.setText("通信状态：数据发送成功(" + data + ")");
                    } else {
                        tvStatus.setText("通信状态：数据发送失败");
                    }
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化UI
        initView();

        // 初始化蓝牙
        initBluetooth();

        // 设置点击事件
        setClickListeners();
    }

    // 初始化UI组件
    private void initView() {
        btnScan = findViewById(R.id.btn_scan);
        lvDevices = findViewById(R.id.lv_devices);
        btnRed = findViewById(R.id.btn_red);
        btnBlue = findViewById(R.id.btn_blue);
        btnClose = findViewById(R.id.btn_close);
        tvStatus = findViewById(R.id.tv_status);

        // 初始化设备列表适配器
        deviceAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        lvDevices.setAdapter(deviceAdapter);
    }

    // 初始化蓝牙
    private void initBluetooth() {
        bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();

        // 检查蓝牙是否可用
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "请开启蓝牙功能", Toast.LENGTH_SHORT).show();
            finish();
        }

        // 检查权限
        checkPermissions();
    }

    // 检查权限
    private void checkPermissions() {
        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+ 蓝牙权限
            permissions = new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            };
        } else {
            // Android 12以下位置权限
            permissions = new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            };
        }

        // 检查未授予的权限
        boolean needRequest = false;
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                needRequest = true;
                break;
            }
        }

        if (needRequest) {
            ActivityCompat.requestPermissions(this, permissions, 1001);
        }
    }

    // 设置点击事件
    private void setClickListeners() {
        // 扫描按钮
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isScanning) {
                    stopScan();
                    btnScan.setText("开始扫描");
                } else {
                    startScan();
                    btnScan.setText("停止扫描");
                }
            }
        });

        // 设备列表点击事件
        lvDevices.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String deviceInfo = (String) parent.getItemAtPosition(position);
                String address = deviceInfo.substring(deviceInfo.indexOf("(") + 1, deviceInfo.indexOf(")"));
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
                connectDevice(device);
            }
        });

        // Red按钮（发送1）
        btnRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("1");
            }
        });

        // Blue按钮（发送2）
        btnBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("2");
            }
        });

        // Close按钮（发送3）
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("3");
            }
        });
    }

    // 开始扫描BLE设备
    private void startScan() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED) {
            checkPermissions();
            return;
        }

        // 清空历史设备
        scannedDevices.clear();
        deviceAdapter.clear();

        // 开始扫描
        isScanning = true;
        bluetoothAdapter.startLeScan(leScanCallback);

        // 定时停止扫描
        scanHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                stopScan();
                btnScan.setText("开始扫描");
            }
        }, SCAN_PERIOD);
    }

    // 停止扫描
    private void stopScan() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        isScanning = false;
        bluetoothAdapter.stopLeScan(leScanCallback);
    }

    // 连接BLE设备
    private void connectDevice(BluetoothDevice device) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            checkPermissions();
            return;
        }

        // 关闭之前的连接
        if (bluetoothGatt != null) {
            bluetoothGatt.close();
        }

        // 连接新设备
        bluetoothGatt = device.connectGatt(this, false, gattCallback);
        tvStatus.setText("通信状态：正在连接" + device.getName() + "...");
    }

    // 查找可写特征
    // 替换为你的BLE设备的实际UUID（示例UUID仅作参考）
    private static final String SERVICE_UUID = "0000ffe0-0000-1000-8000-00805f9b34fb"; // 设备服务UUID
    private static final String WRITE_CHARACTERISTIC_UUID = "0000ffe1-0000-1000-8000-00805f9b34fb"; // 可写特征UUID

    // 重构查找可写特征的方法
    private void findWritableCharacteristic(BluetoothGatt gatt) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        // 1. 根据服务UUID找到目标服务
        BluetoothGattService targetService = gatt.getService(UUID.fromString(SERVICE_UUID));
        if (targetService == null) {
            runOnUiThread(() -> tvStatus.setText("通信状态：未找到目标服务"));
            return;
        }

        // 2. 根据特征UUID找到目标可写特征
        BluetoothGattCharacteristic targetChar = targetService.getCharacteristic(UUID.fromString(WRITE_CHARACTERISTIC_UUID));
        if (targetChar == null) {
            runOnUiThread(() -> tvStatus.setText("通信状态：未找到目标特征"));
            return;
        }

        // 3. 验证特征是否可写
        int properties = targetChar.getProperties();
        if ((properties & BluetoothGattCharacteristic.PROPERTY_WRITE) > 0 ||
                (properties & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) > 0) {
            writeCharacteristic = targetChar;
            runOnUiThread(() -> tvStatus.setText("通信状态：已连接，可发送数据"));
        } else {
            runOnUiThread(() -> tvStatus.setText("通信状态：特征不可写（属性值：" + properties + "）"));
        }
    }

    // 发送数据
    private void sendData(String data) {
        if (bluetoothGatt == null) {
            Toast.makeText(this, "未连接蓝牙设备", Toast.LENGTH_SHORT).show();
            return;
        }

        if (writeCharacteristic == null) {
            Toast.makeText(this, "未找到可写特征", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            checkPermissions();
            return;
        }

        // 设置发送数据
        writeCharacteristic.setValue(data.getBytes(StandardCharsets.UTF_8));

        // 发送数据
        bluetoothGatt.writeCharacteristic(writeCharacteristic);
        tvStatus.setText("通信状态：正在发送数据(" + data + ")...");
    }

    // 权限请求结果
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1001) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "需要授予权限才能使用蓝牙功能", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        }
    }

    // 生命周期管理
    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopScan();
        if (bluetoothGatt != null) {
            bluetoothGatt.close();
            bluetoothGatt = null;
        }
    }
}